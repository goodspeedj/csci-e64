function changeColor(id, color) {
    document.getElementById(id).setAttribute("fill", color);
}